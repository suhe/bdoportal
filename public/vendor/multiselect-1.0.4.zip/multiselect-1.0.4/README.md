multiselect
===========

jQuery multiselect plugin with two sides. The user can select one or more items and send them to the other side.

# [Demo](http://crlcu.github.com/multiselect/)